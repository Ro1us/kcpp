#ifndef ZADPUNKT_H
#define ZADPUNKT_H

#include "ZadKcpp.h"

class ZadPlus : public ZadKcpp
{
public:
    void Uruchom() override;
};

#endif