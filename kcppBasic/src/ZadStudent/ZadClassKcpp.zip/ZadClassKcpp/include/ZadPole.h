#ifndef ZADPOLE_H
#define ZADPOLE_H

#include "ZadKcpp.h"

class ZadPole : public ZadKcpp
{
public:
    void Uruchom() override;
};

#endif