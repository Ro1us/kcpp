#ifndef ZADPARZYSTA_H
#define ZADPARZYSTA_H

#include "ZadKcpp.h"

class ZadParzysta : public ZadKcpp
{
public:
    void Uruchom() override;
};

#endif