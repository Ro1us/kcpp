#ifndef ZADDODAJ_H
#define ZADDODAJ_H

#include "ZadKcpp.h"

class ZadDodaj : public ZadKcpp
{
public:
    void Uruchom() override;
};

#endif