#ifndef ZADSUMA_H
#define ZADSUMA_H

#include "ZadKcpp.h"

class ZadSuma : public ZadKcpp
{
public:
    void Uruchom() override;
};

#endif