#include <iostream>

#include "include/ZadString.h"
#include "include/ZadPole.h"
#include "include/ZadDodaj.h"
#include "include/ZadPlus.h"
#include "include/ZadSuma.h"
#include "include/ZadMax.h"
#include "include/ZadParzysta.h"
#include "include/ZadClass.h"
#include "include/ZadKonstruktor.h"
#include "include/ZadMetodyAbstrakcyjne.h"
using namespace std;
int main()
{
    int wybor;
    do
    {
        cout << endl;
        cout << "==================================" << endl;
        cout << "      ZadClassKcpp - MENU" << endl;
        cout << "==================================" << endl;
        cout << "1.  ZadString (1.3 String)" << endl;
        cout << "2.  ZadPole (2.2 Pole figur)" << endl;
        cout << "3.  ZadDodaj (2.3 Przeciazanie funkcji)" << endl;
        cout << "4.  ZadPlus (2.4 Operator +)" << endl;
        cout << "5.  ZadSuma (3.2 Suma tablicy)" << endl;
        cout << "6.  ZadMax (3.3 Najwiekszy element)" << endl;
        cout << "7.  ZadParzysta (4.7 Parzysta/Nieparzysta)" << endl;
        cout << "8.  ZadClass (5.1 Klasa)" << endl;
        cout << "9.  ZadKonstruktor (5.4 Konstruktory)" << endl;
        cout << "10. ZadMetodyAbstrakcyjne (5.6)" << endl;
        cout << "0.  Wyjscie" << endl;
        cout << endl;
        cout << "Wybor: ";
        cin >> wybor;
        cout << endl;
        switch(wybor)
        {
        case 1:
            {
                ZadString zad;
                zad.Uruchom();
                break;
            }
        case 2:
            {
                ZadPole zad;
                zad.Uruchom();
                break;
            }
        case 3:
            {
                ZadDodaj zad;
                zad.Uruchom();
                break;
            }
        case 4:
            {
                ZadPlus zad;
                zad.Uruchom();
                break;
            }
        case 5:
            {
                ZadSuma zad;
                zad.Uruchom();
                break;
            }
        case 6:
            {
                ZadMax zad;
                zad.Uruchom();
                break;
            }
        case 7:
            {
                ZadParzysta zad;
                zad.Uruchom();
                break;
            }

        case 8:
            {
                ZadClass zad;
                zad.Uruchom();
                break;
            }
        case 9:
            {
                ZadKonstruktor zad;
                zad.Uruchom();
                break;
            }
        case 10:
            {
                ZadMetodyAbstrakcyjne zad;
                zad.Uruchom();
                break;
            }
        case 0:
            {
                cout << "Koniec programu." << endl;
                break;
            }
        default:
            {
                cout << "Nieprawidlowy wybor!" << endl;
                break;
            }
        }
    } while (wybor != 0);
    return 0;
}